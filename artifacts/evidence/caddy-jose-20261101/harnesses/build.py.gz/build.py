import os,sys,subprocess,json,hashlib,time
from pathlib import Path
r=Path(__file__).resolve().parent.parent; s=r/'source'; go='/Users/michaelwong/Library/Caches/AI-Development/toolchains/go1.26.10/bin/go'
def run(args,env=None,out=None):
 print('RUN',args,flush=True)
 if out:
  with out.open('x') as f: subprocess.run(args,cwd=s,env=env,stdout=f,check=True)
 else: subprocess.run(args,cwd=s,env=env,check=True)
run([go,'mod','verify'])
run([go,'test','-mod=readonly','-count=1','-timeout=30s','-v','-run','^TestJWKSecurityBoundaries$','.'])
records=[]
for target in ('linux-amd64','linux-arm64','darwin-arm64'):
 env=os.environ.copy();env['GOOS'],env['GOARCH']=target.split('-');env['CGO_ENABLED']='0';env['GOFLAGS']='-p=2 -mod=readonly'
 binary=r/'bin'/('caddy-'+target)
 run([go,'build','-buildvcs=false','-trimpath','-ldflags','-s -w','-o',str(binary),'.'],env)
 run([go,'version','-m',str(binary)],out=r/'reports'/(target+'-buildinfo.txt'))
 if target.startswith('linux'):
  run([go,'list','-deps','-json','.'],env,out=r/'reports'/(target+'-deps.ndjson'))
 records.append({'target':target,'bytes':binary.stat().st_size,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()})
 (r/'reports/builds.json').write_text(json.dumps(records,indent=2)+'\n')
 print(records[-1],flush=True)
