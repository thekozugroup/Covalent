import importlib.util,sys,json,hashlib,urllib.request,tarfile,gzip,io
from pathlib import Path
r=Path(__file__).resolve().parent.parent;repo=Path('/Users/michaelwong/Developer/Covalent')
def module(name,file):
 spec=importlib.util.spec_from_file_location(name,repo/'scripts'/file);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
c=module('caddy_collector','collect-caddy-distribution-evidence.py');v=module('caddy_verifier','verify-caddy-distribution-evidence.py')
p=r/'ca-input';p.mkdir(exist_ok=True);raw=urllib.request.urlopen('https://dl-cdn.alpinelinux.org/alpine/v3.23/main/x86_64/ca-certificates-bundle-20261020-r0.apk',timeout=30).read(107117)
assert len(raw)==107116 and hashlib.sha256(raw).hexdigest()=='a4c5de1bf37652cd98cbe71aec209512ae0508a964961957a6c9650f795e46c4'
(p/'ca-bundle.apk').write_bytes(raw)
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(raw)),mode='r:',ignore_zeros=True) as tar:
 member=tar.getmember('etc/ssl/certs/ca-certificates.crt');assert member.isfile();bundle=tar.extractfile(member).read()
assert len(bundle)==178791 and hashlib.sha256(bundle).hexdigest()==c.CA_BUNDLE_SHA256
(p/'ca-certificates.crt').write_bytes(bundle)
ref=r/'reference';ref.mkdir()
(ref/'README.md').write_text('Source/reference qualification only. The ELF binaries, target Go graphs and license bytes are real. CA provenance is the unchanged reviewed source record; it is not a fresh installed APK database or native container receipt. CI must regenerate against actual installed metadata. No production collector/verifier bypass is added.\n')
for arch in ('amd64','arm64'):
 target='linux-'+arch
 # Model unchanged CA provenance for reference generation only; no fake installed DB.
 ca=dict(v.CA_RECORD);ca['architecture']={'amd64':'x86_64','arm64':'noarch'}[arch]
 c._ca_provenance=lambda *_args,record=ca:dict(record)
 manifest=c.collect(r/'source',r/'gomodcache',Path('/Users/michaelwong/Library/Caches/AI-Development/toolchains/go1.26.10'),[c.Target(target,'linux',arch,r/'reports'/(target+'-deps.ndjson'))],r/'bin'/('caddy-'+target),p/'NO-INSTALLED-DB',p/'ca-certificates.crt',ref/target)
 summary={'referenceOnly':True,'target':target,'packageCount':manifest['targets'][0]['packageCount'],'moduleCount':manifest['moduleCount'],'inventorySha256':manifest['inventory']['sha256'],'noticeSha256':manifest['combinedNotice']['sha256'],'binarySha256':manifest['binary']['sha256'],'unclassified':manifest['unclassifiedLicenseEvidence'],'licenseFamilyModuleCounts':manifest['licenseFamilyModuleCounts']}
 (r/'reports'/(target+'-reference.json')).write_text(json.dumps(summary,indent=2)+'\n');print(summary,flush=True)
