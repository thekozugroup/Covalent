import os, json, subprocess, socket, threading, http.server, time, ssl, urllib.request, hashlib, stat
from pathlib import Path

r = Path(__file__).resolve().parent.parent
work = r / 'runtime'
work.mkdir()
receipt = work / 'receipt.json'
binary = r / 'bin/caddy-darwin-arm64'
value = {'scope': 'Host runtime; shipped Caddyfile adapted for task paths/ports and install_trust=false. Not native Linux image proof.', 'state': 'planned', 'processes': [], 'ports': {}, 'checks': []}
def save():
    receipt.write_text(json.dumps(value, indent=2) + '\n')
def identity(pid):
    return subprocess.check_output(['ps', '-p', str(pid), '-o', 'pid=,lstart=,comm='], text=True).strip()
def freeport():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]
def check(ok, label):
    assert ok, label
    value['checks'].append(label)
    save()
save()
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass
    def do_GET(self):
        body = b'data: first\n\ndata: done\n\n' if self.path == '/events' else b'{"ok":true}'
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream' if self.path == '/events' else 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)
        self.wfile.flush()
server = http.server.HTTPServer(('127.0.0.1', 0), Handler)
value['processes'].append({'role': 'backend thread in harness', 'identity': identity(os.getpid())})
value['ports'] = {'backend': server.server_port, 'https': freeport(), 'httpRedirect': freeport()}
save()
thread = threading.Thread(target=server.serve_forever)
thread.start()
child = None
try:
    adapted = subprocess.run([str(binary), 'adapt', '--config', '/Users/michaelwong/Developer/Covalent/packaging/docker/Caddyfile', '--adapter', 'caddyfile'], capture_output=True, check=True)
    (work / 'adapt-stderr.log').write_bytes(adapted.stderr)
    config = json.loads(adapted.stdout)
    web = work / 'web'
    web.mkdir()
    (web / 'index.html').write_text('Interlink local console')
    sock = work / 'console.sock'
    replacements = {'/usr/local/share/covalent/web': str(web), '127.0.0.1:8787': '127.0.0.1:' + str(server.server_port), 'unix//config/covalent-web.sock|0600': 'unix/' + str(sock) + '|0600', ':8443': '127.0.0.1:' + str(value['ports']['https'])}
    def relocate(x):
        if isinstance(x, dict):
            return {k: relocate(v) for k, v in x.items()}
        if isinstance(x, list):
            return [relocate(v) for v in x]
        return replacements.get(x, x) if isinstance(x, str) else x
    config = relocate(config)
    config['apps']['pki'] = {'certificate_authorities': {'local': {'install_trust': False}}}
    config['apps']['http']['http_port'] = value['ports']['httpRedirect']
    path = work / 'config.json'
    path.write_text(json.dumps(config, indent=2) + '\n')
    env = os.environ.copy()
    env['XDG_CONFIG_HOME'] = str(work / 'config')
    env['XDG_DATA_HOME'] = str(work / 'data')
    def start(name):
        with (work / (name + '.log')).open('x') as log:
            p = subprocess.Popen([str(binary), 'run', '--config', str(path)], stdout=log, stderr=subprocess.STDOUT, env=env)
        value['processes'].append({'role': name, 'pid': p.pid, 'identity': identity(p.pid)})
        save()
        return p
    def stop(p):
        p.terminate()
        try:
            p.wait(timeout=10)
        except subprocess.TimeoutExpired:
            p.kill()
            p.wait(timeout=5)
            raise
    child = start('first-start')
    root = work / 'data/caddy/pki/authorities/local/root.crt'
    deadline = time.monotonic() + 20
    while not root.is_file():
        if child.poll() is not None:
            raise RuntimeError('Caddy exited before CA initialization')
        if time.monotonic() > deadline:
            raise TimeoutError('Caddy CA initialization')
        time.sleep(.1)
    context = ssl.create_default_context(cafile=str(root))
    base = 'https://localhost:' + str(value['ports']['https'])
    def get(path):
        return urllib.request.urlopen(base + path, context=context, timeout=5)
    def ready():
        deadline = time.monotonic() + 15
        while True:
            try:
                return get('/api/test')
            except OSError:
                if time.monotonic() > deadline:
                    raise
                time.sleep(.1)
    response = ready()
    check(response.read() == b'{"ok":true}', 'HTTPS reverse proxy using generated CA')
    check(response.headers.get('X-Content-Type-Options') == 'nosniff', 'Security headers retained')
    check('max-age=' in response.headers.get('Strict-Transport-Security', ''), 'HSTS retained')
    check(get('/').read() == b'Interlink local console', 'Static console route')
    check(get('/events').read() == b'data: first\n\ndata: done\n\n', 'Event-stream response preserved')
    check(sock.is_socket() and stat.S_IMODE(sock.stat().st_mode) == 0o600, 'Owner-only Unix ingress')
    def pki_hashes():
        return {str(p.relative_to(root.parent)): hashlib.sha256(p.read_bytes()).hexdigest() for p in root.parent.iterdir() if p.is_file()}
    before = pki_hashes()
    stop(child)
    child = None
    child = start('second-start')
    check(ready().read() == b'{"ok":true}', 'HTTPS proxy after restart')
    check(pki_hashes() == before, 'Existing CA key and certificate bytes preserved after restart')
    value['pkiHashes'] = before
    value['state'] = 'passed'
    save()
finally:
    if child is not None and child.poll() is None:
        stop(child)
    server.shutdown()
    thread.join(timeout=5)
    server.server_close()
    value['cleanup'] = {'caddyStopped': child is None or child.poll() is not None, 'backendThreadStopped': not thread.is_alive(), 'hostTrustInstallation': False}
    save()
print(json.dumps(value), flush=True)
