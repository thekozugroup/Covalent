import sys,subprocess,json,hashlib,os
from pathlib import Path
r=Path(__file__).resolve().parent.parent
for target in sys.argv[1:]:
 binary=r/'bin'/('caddy-'+target);sbom=r/'reports'/(target+'-syft.json');report=r/'reports'/(target+'-grype.json')
 subprocess.run(['syft','file:'+str(binary),'-o','json='+str(sbom)],check=True)
 b=json.loads(sbom.read_text());packages=b['artifacts']; assert len(packages)>100
 selected={a['name']:a['version'] for a in packages if a['name'].startswith('github.com/go-jose/')}
 assert selected=={'github.com/go-jose/go-jose/v3':'v3.0.6-0.20261030183946-0e502b87c7aa','github.com/go-jose/go-jose/v4':'v4.1.7'},selected
 result=subprocess.run(['grype','sbom:'+str(sbom),'-o','json','--file',str(report),'--fail-on','high'])
 value=json.loads(report.read_text());counts={}
 for item in value['matches']:
  severity=item['vulnerability']['severity'];counts[severity]=counts.get(severity,0)+1
 summary={'target':target,'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sbomSha256':hashlib.sha256(sbom.read_bytes()).hexdigest(),'sbomPackageCount':len(packages),'JOSE':selected,'scanExit':result.returncode,'reportSha256':hashlib.sha256(report.read_bytes()).hexdigest(),'findings':counts,'database':value['descriptor']['db']}
 (r/'reports'/(target+'-scan-summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps(summary),flush=True)
 if result.returncode:sys.exit(result.returncode)
